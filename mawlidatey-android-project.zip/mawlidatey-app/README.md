# مولدتي الأول — Android project

An Android WebView wrapper around the offline Arabic HTML app.

- App label: مولدتي الأول
- Android application ID: `com.mooalidatey_app`
- Offline page: `app/src/main/assets/index.html`
- Local data: browser localStorage inside the app WebView

## Build
Open this folder in Android Studio and run `assembleDebug`, or upload the folder contents to a GitHub repository and run the workflow in `.github/workflows/build-apk.yml`.

The debug APK output path is `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
This is a starter build. Test all flows on the target phone before relying on it for business records. Browser print/PDF and popup behavior can vary in WebView; the app's receipt flow should be tested on-device. Export a backup regularly.
